<?
echo 'haha this ia test hehehe';
phpinfo();
?>